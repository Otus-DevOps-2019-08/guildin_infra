# -*- coding:utf-8 -*-
# vim: set ts=2 sw=2 sts=2 et:

# ( GLOBALS
VERSION = '0.5.19'
AUTHOR_NAME = 'Diego Blanco'
AUTHOR_MAIL = 'diego.blanco@treitos.com'
URL = 'https://github.com/diego-treitos/ansible-inventory'
# )
